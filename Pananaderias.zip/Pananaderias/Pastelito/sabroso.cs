﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pastelito
{
    public class sabroso
    {
        public int id { get; set; }
        public string Nombre { get; set; }
        public int Numero { get; set; }
        public string Email { get; set; }
        public string Direccion { get; set; }
        public string Encargado { get; set; }
        public string Sitio { get; set; }

        public sabroso(int id, string Nombre, int Numero, string Email, string Direccion, string Encargado, string sitio) 
        {
            this.id = id;
            this.Nombre = Nombre;
            this.Numero = Numero;
            this.Email = Email;
            this.Direccion = Direccion;
            this.Encargado = Encargado;
            this.Sitio = sitio;
                

        }
        public int Id()
        {
            return id;
        }
        public string nombre()
        {
            return Nombre;
        }
        public int numero()
        {
            return Numero;
        }
        public string email() 
        {
            return Email;
        }
        public string direccion() 
        {
            return Direccion;
        }
        public string encargado()
        {
            return Encargado;
        }
        public string sitio()
        {
            return Sitio;
        }



    }
}
