﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pastelito;

namespace Pananaderias.forms
{
    public partial class panes : Form
    {
        public panes()
        {
            InitializeComponent();
        }

        private void AgregarButton_Click(object sender, EventArgs e)
        {
            if (int.TryParse(IdTextBox.Text, out int Id) &&
                int.TryParse(NumeroTextBox.Text, out int numero) &&
                !string.IsNullOrWhiteSpace(NombreTextBox.Text) &&
                !string.IsNullOrWhiteSpace(EmailTextBox.Text) &&
                !string.IsNullOrWhiteSpace(DireccionTextBox.Text) &&
                !string.IsNullOrWhiteSpace(EncargadoTextBox.Text) &&
                !string.IsNullOrWhiteSpace(SitioTextBox.Text))
            {

                string nombre = NombreTextBox.Text;
                string Email = EmailTextBox.Text;
                string Direccion = DireccionTextBox.Text;
                string Encargado = EncargadoTextBox.Text;
                string Sitio = SitioTextBox.Text;

                sabroso Panaderia = new sabroso(Id, nombre,numero, Email, Direccion, Encargado, Sitio);

                listBox1.Items.Add(Panaderia.Id());
                listBox1.Items.Add(Panaderia.numero());
                listBox1.Items.Add(Panaderia.nombre());
                listBox1.Items.Add(Panaderia.email());
                listBox1.Items.Add(Panaderia.direccion());
                listBox1.Items.Add(Panaderia.encargado());
                listBox1.Items.Add(Panaderia.sitio());
              
            }
            else
            {
                MessageBox.Show("El valor ingresado no es valido");
            }

        }

        private void EliminarButton_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                listBox1.Items.Remove(listBox1.SelectedItem);
            }
        }
    }
}
